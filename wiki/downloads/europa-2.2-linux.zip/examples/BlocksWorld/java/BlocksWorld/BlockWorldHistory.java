package BlocksWorld;

public interface BlockWorldHistory
{
	public void add(int stepCount,BlockWorld bw,String operatorHistory);
}