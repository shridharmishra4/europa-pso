#!/usr/bin/env ruby
#
# Put description here
#
# 
# 
# 
#

require 'swig_assert'

require 'typemap_ns_using'

raise RuntimeError unless Typemap_ns_using.spam(37) == 37

